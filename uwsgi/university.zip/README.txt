/**********************************************************************
 * All teammates' names                                               *
 **********************************************************************/

Jonah Scudere-Weiss
Chloe Halverson
Skye Whitlow
Audrey Roller

/**********************************************************************
 * Approximate number of hours to complete this assignment            *
 **********************************************************************/

Number of hours for 1st TEAMMATE's NAME: 3.5

Number of hours for 2nd TEAMMATE's NAME: 3.666

Number of hours for 3rd TEAMMATE's NAME: 3

Number of hours for 4th TEAMMATE's NAME: 3


/**********************************************************************
 * Were all teammates able to get the example apps running on         *
 * their own devices? If not please explain.                          *
 **********************************************************************/


Yes 


/**********************************************************************
 * Do you attest that this work is your own, in accordance with       *
 * the statement on academic integrity in the syllabus?               *
 **********************************************************************/


Yes


/**********************************************************************
 * List any other comments here.                                      *
 **********************************************************************/
Updating capacity for enrollments didnt make sense, as i is pretty much just a primary key, as such we have opted to just maintain that as C R and D.